﻿namespace MVCSkeleton.Application.Session
{
    public interface ISessionAdapter
    {
        void Commit();

        void Rollback();
    }
}