﻿namespace MVCSkeleton.DTOs
{
    public class UserDTO
    {
        public long Id { get; set; }

        public string Name { get; set; }

        public string Password { get; set; }
    }
}