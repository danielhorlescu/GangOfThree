namespace MVCSkeleton.ApplicationStartup
{
    public interface IApplicationStartupModule
    {
        void Load();
    }
}