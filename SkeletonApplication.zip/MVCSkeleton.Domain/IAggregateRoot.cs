namespace MVCSkeleton.Domain
{
    public interface IAggregateRoot : IEntity
    {
    }
}