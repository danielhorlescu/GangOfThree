namespace MVCSkeleton.Domain
{
    public interface IEntity
    {
        long Id { get; set; }
    }
}