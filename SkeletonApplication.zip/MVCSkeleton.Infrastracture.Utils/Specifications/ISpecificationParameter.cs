namespace MVCSkeleton.Infrastracture.Utils.Specifications
{
    public interface ISpecificationParameter
    {
        string ParameterName { get; }
        object ParameterValue { get; }
    }
}
